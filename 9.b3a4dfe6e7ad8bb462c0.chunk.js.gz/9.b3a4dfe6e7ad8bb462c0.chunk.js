webpackJsonp([9],{

/***/ 829:
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	exports.CodeSnippet = undefined;
	
	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();
	
	var _dec, _class;
	
	var _core = __webpack_require__(1);
	
	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
	
	var CodeSnippet = exports.CodeSnippet = (_dec = (0, _core.Component)({
	    inputs: ['code'],
	    selector: 'code-snippet',
	    template: '<pre><code [innerHtml]="highlight"></code></pre>'
	}), _dec(_class = function () {
	    function CodeSnippet() {
	        _classCallCheck(this, CodeSnippet);
	    }
	
	    _createClass(CodeSnippet, [{
	        key: 'ngOnInit',
	        value: function ngOnInit() {
	            this.highlight = hljs.highlightAuto(this.code).value;
	        }
	    }]);
	
	    return CodeSnippet;
	}()) || _class);
	//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRlbW8vZWxlbWVudHMvY29kZXNuaXBwZXQvQ29kZVNuaXBwZXQuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBQTs7OztJQU9hLFcsV0FBQSxXLFdBTFoscUJBQVU7QUFDUCxZQUFRLENBQUMsTUFBRCxDQUREO0FBRVAsY0FBVSxjQUZIO0FBR1AsY0FBVTtBQUhILENBQVYsQzs7Ozs7OzttQ0FNYztBQUNQLGlCQUFLLFNBQUwsR0FBaUIsS0FBSyxhQUFMLENBQW1CLEtBQUssSUFBeEIsRUFBOEIsS0FBL0M7QUFDSCIsImZpbGUiOiJDb2RlU25pcHBldC5qcyIsInNvdXJjZVJvb3QiOiIvVXNlcnMvamdvZGkvbm92by1kZXYvbGlicy9ub3ZvLWVsZW1lbnRzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbkBDb21wb25lbnQoe1xuICAgIGlucHV0czogWydjb2RlJ10sXG4gICAgc2VsZWN0b3I6ICdjb2RlLXNuaXBwZXQnLFxuICAgIHRlbXBsYXRlOiAnPHByZT48Y29kZSBbaW5uZXJIdG1sXT1cImhpZ2hsaWdodFwiPjwvY29kZT48L3ByZT4nXG59KVxuZXhwb3J0IGNsYXNzIENvZGVTbmlwcGV0IHtcbiAgICBuZ09uSW5pdCgpIHtcbiAgICAgICAgdGhpcy5oaWdobGlnaHQgPSBobGpzLmhpZ2hsaWdodEF1dG8odGhpcy5jb2RlKS52YWx1ZTtcbiAgICB9XG59XG4iXX0=

/***/ },

/***/ 409:
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	exports.QuickNoteDemo = exports.CustomQuickNoteResults = undefined;
	
	var _dec, _class, _dec2, _class2;
	
	var _core = __webpack_require__(1);
	
	var _common = __webpack_require__(5);
	
	var _novoElements = __webpack_require__(13);
	
	var _CodeSnippet = __webpack_require__(829);
	
	var _BasicQuickNote = __webpack_require__(879);
	
	var _BasicQuickNote2 = _interopRequireDefault(_BasicQuickNote);
	
	var _CustomQuickNote = __webpack_require__(880);
	
	var _CustomQuickNote2 = _interopRequireDefault(_CustomQuickNote);
	
	var _CustomQuickNoteResults = __webpack_require__(881);
	
	var _CustomQuickNoteResults2 = _interopRequireDefault(_CustomQuickNoteResults);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
	
	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }
	
	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
	
	var CustomQuickNoteResults = exports.CustomQuickNoteResults = (_dec = (0, _core.Component)({
	    selector: 'custom-quick-note-results',
	    directives: [_novoElements.NOVO_LOADING_ELEMENTS],
	    host: {
	        'class': 'active quick-note-results'
	    },
	    template: '\n        <novo-loading theme="line" *ngIf="isLoading && !matches.length"></novo-loading>\n        <ul *ngIf="matches.length > 0">\n            <li\n                *ngFor="let match of matches"\n                (click)="selectMatch($event)"\n                [class.active]="match===activeMatch"\n                (mouseenter)="selectActive(match)">\n                **CUSTOM** <b [innerHtml]="highlight(match.label, term)"></b>\n            </li>\n        </ul>\n        <p class="picker-error" *ngIf="hasError">Oops! An error occured.</p>\n        <p class="picker-null" *ngIf="!isLoading && !matches.length && !hasError">No results to display...</p>\n    '
	}), _dec(_class = function (_QuickNoteResults) {
	    _inherits(CustomQuickNoteResults, _QuickNoteResults);
	
	    function CustomQuickNoteResults() {
	        _classCallCheck(this, CustomQuickNoteResults);
	
	        return _possibleConstructorReturn(this, Object.getPrototypeOf(CustomQuickNoteResults).apply(this, arguments));
	    }
	
	    return CustomQuickNoteResults;
	}(_novoElements.QuickNoteResults)) || _class);
	
	
	var template = '\n<div class="container">\n    <h1>Quick Note <small><a target="_blank" href="https://github.com/bullhorn/novo-elements/tree/master/src/elements/quick-note">(source)</a></small></h1>\n    <p>Tag Autocomplete</p>\n\n    <br/>\n\n    <h5>Basic Examples</h5>\n    <div class="example quick-note-demo">' + _BasicQuickNote2.default + '</div>\n    <code-snippet [code]="BasicQuickNoteDemoTpl"></code-snippet>\n    \n    <h5>Custom Triggers</h5>\n    <div class="example quick-note-demo">' + _CustomQuickNote2.default + '</div>\n    <code-snippet [code]="CustomQuickNoteDemoTpl"></code-snippet>\n    \n    <h5>Custom Results Template</h5>\n    <div class="example quick-note-demo">' + _CustomQuickNoteResults2.default + '</div>\n    <code-snippet [code]="CustomQuickNoteResultsDemoTpl"></code-snippet>\n</div>\n';
	
	var QuickNoteDemo = exports.QuickNoteDemo = (_dec2 = (0, _core.Component)({
	    selector: 'quick-note-demo',
	    template: template,
	    directives: [_novoElements.NOVO_QUICK_NOTE_ELEMENTS, _common.CORE_DIRECTIVES, _CodeSnippet.CodeSnippet]
	}), _dec2(_class2 = function QuickNoteDemo() {
	    _classCallCheck(this, QuickNoteDemo);
	
	    this.BasicQuickNoteDemoTpl = _BasicQuickNote2.default;
	    this.CustomQuickNoteDemoTpl = _CustomQuickNote2.default;
	    this.CustomQuickNoteResultsDemoTpl = _CustomQuickNoteResults2.default;
	
	    this.placeholder = 'Enter your note text here. Reference people and distrubution lists using @ (eg. @John Smith). Reference other records using # (e.g. #Project Manager)';
	
	    this.note = '';
	    this.references = {};
	
	    this.note2 = 'I am an initial note!';
	    this.references2 = {};
	
	    this.note3 = '';
	    this.references3 = {};
	
	    var customData = {
	        tags: [{ id: 1, name: 'OH YA!', test: 'TWO' }, { id: 2, name: 'TAGGING!', test: 'ONE' }],
	        references: [{ id: 1, title: 'Awesome Reference' }, { id: 2, title: 'Angular2' }]
	    };
	
	    this.config = {
	        triggers: {
	            tags: '@',
	            references: '#',
	            boos: '^'
	        },
	        options: {
	            tags: ['First', 'Second'],
	            references: ['Third', 'Forth'],
	            boos: ['Test']
	        },
	        renderer: {
	            tags: function tags(symbol, item) {
	                return '<a class="tag">' + symbol + item.label + '</a>';
	            },
	            references: function references(symbol, item) {
	                return '<a class="tag">' + symbol + item.label + '</a>';
	            },
	            boos: function boos(symbol, item) {
	                return '<strong>' + symbol + item.label + '</strong>';
	            }
	        }
	    };
	
	    this.custom = {
	        triggers: {
	            whos: '@',
	            whats: '#'
	        },
	        options: {
	            whos: function whos() {
	                return new Promise(function (resolve) {
	                    setTimeout(function () {
	                        resolve(customData.tags);
	                    }, 300);
	                });
	            },
	            whats: function whats() {
	                return new Promise(function (resolve) {
	                    setTimeout(function () {
	                        resolve(customData.references);
	                    }, 300);
	                });
	            }
	        },
	        format: {
	            whos: '$name $test',
	            whats: '$title'
	        },
	        renderer: {
	            whos: function whos(symbol, item) {
	                return '<a class="WHOS">' + symbol + item.label + '</a>';
	            },
	            whats: function whats(symbol, item) {
	                return '<a class="tag">' + symbol + item.label + '</a>';
	            }
	        }
	    };
	
	    this.custom2 = {
	        resultsTemplate: CustomQuickNoteResults,
	        triggers: {
	            names: '@',
	            tags: '#'
	        },
	        options: {
	            names: function names() {
	                return new Promise(function (resolve) {
	                    setTimeout(function () {
	                        resolve(customData.tags);
	                    }, 300);
	                });
	            },
	            tags: function tags() {
	                return new Promise(function (resolve) {
	                    setTimeout(function () {
	                        resolve(customData.references);
	                    }, 300);
	                });
	            }
	        },
	        format: {
	            names: '$name',
	            tags: '$title'
	        },
	        renderer: {
	            names: function names(symbol, item) {
	                return '<a class="names">' + symbol + item.label + '</a>';
	            },
	            tags: function tags(symbol, item) {
	                return '<a class="tags">' + symbol + item.label + '</a>';
	            }
	        }
	    };
	}) || _class2);
	//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRlbW8vcGFnZXMvcXVpY2stbm90ZS9RdWlja05vdGVEZW1vLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBOztBQUNBOztBQUNBOztBQUVBOztBQUVBOzs7O0FBQ0E7Ozs7QUFDQTs7Ozs7Ozs7Ozs7O0lBdUJhLHNCLFdBQUEsc0IsV0FyQloscUJBQVU7QUFDUCxjQUFVLDJCQURIO0FBRVAsZ0JBQVkscUNBRkw7QUFHUCxVQUFNO0FBQ0YsaUJBQVM7QUFEUCxLQUhDO0FBTVA7QUFOTyxDQUFWLEM7Ozs7Ozs7Ozs7Ozs7QUF3QkQsSUFBTSxpekJBQU47O0lBMEJhLGEsV0FBQSxhLFlBTFoscUJBQVU7QUFDUCxjQUFVLGlCQURIO0FBRVAsY0FBVSxRQUZIO0FBR1AsZ0JBQVk7QUFITCxDQUFWLEMsa0JBTUcseUJBQWM7QUFBQTs7QUFDVixTQUFLLHFCQUFMO0FBQ0EsU0FBSyxzQkFBTDtBQUNBLFNBQUssNkJBQUw7O0FBRUEsU0FBSyxXQUFMLEdBQW1CLHVKQUFuQjs7QUFFQSxTQUFLLElBQUwsR0FBWSxFQUFaO0FBQ0EsU0FBSyxVQUFMLEdBQWtCLEVBQWxCOztBQUVBLFNBQUssS0FBTCxHQUFhLHVCQUFiO0FBQ0EsU0FBSyxXQUFMLEdBQW1CLEVBQW5COztBQUVBLFNBQUssS0FBTCxHQUFhLEVBQWI7QUFDQSxTQUFLLFdBQUwsR0FBbUIsRUFBbkI7O0FBRUEsUUFBSSxhQUFhO0FBQ2IsY0FBTSxDQUFDLEVBQUUsSUFBSSxDQUFOLEVBQVMsTUFBTSxRQUFmLEVBQXlCLE1BQU0sS0FBL0IsRUFBRCxFQUF5QyxFQUFFLElBQUksQ0FBTixFQUFTLE1BQU0sVUFBZixFQUEyQixNQUFNLEtBQWpDLEVBQXpDLENBRE87QUFFYixvQkFBWSxDQUFDLEVBQUUsSUFBSSxDQUFOLEVBQVMsT0FBTyxtQkFBaEIsRUFBRCxFQUF3QyxFQUFFLElBQUksQ0FBTixFQUFTLE9BQU8sVUFBaEIsRUFBeEM7QUFGQyxLQUFqQjs7QUFLQSxTQUFLLE1BQUwsR0FBYztBQUNWLGtCQUFVO0FBQ04sa0JBQU0sR0FEQTtBQUVOLHdCQUFZLEdBRk47QUFHTixrQkFBTTtBQUhBLFNBREE7QUFNVixpQkFBUztBQUNMLGtCQUFNLENBQUMsT0FBRCxFQUFVLFFBQVYsQ0FERDtBQUVMLHdCQUFZLENBQUMsT0FBRCxFQUFVLE9BQVYsQ0FGUDtBQUdMLGtCQUFNLENBQUMsTUFBRDtBQUhELFNBTkM7QUFXVixrQkFBVTtBQUNOLGtCQUFNLGNBQUMsTUFBRCxFQUFTLElBQVQsRUFBa0I7QUFDcEIsMkNBQXlCLE1BQXpCLEdBQWtDLEtBQUssS0FBdkM7QUFDSCxhQUhLO0FBSU4sd0JBQVksb0JBQUMsTUFBRCxFQUFTLElBQVQsRUFBa0I7QUFDMUIsMkNBQXlCLE1BQXpCLEdBQWtDLEtBQUssS0FBdkM7QUFDSCxhQU5LO0FBT04sa0JBQU0sY0FBQyxNQUFELEVBQVMsSUFBVCxFQUFrQjtBQUNwQixvQ0FBa0IsTUFBbEIsR0FBMkIsS0FBSyxLQUFoQztBQUNIO0FBVEs7QUFYQSxLQUFkOztBQXdCQSxTQUFLLE1BQUwsR0FBYztBQUNWLGtCQUFVO0FBQ04sa0JBQU0sR0FEQTtBQUVOLG1CQUFPO0FBRkQsU0FEQTtBQUtWLGlCQUFTO0FBQ0wsa0JBQU0sZ0JBQU07QUFDUix1QkFBTyxJQUFJLE9BQUosQ0FBWSxVQUFDLE9BQUQsRUFBYTtBQUM1QiwrQkFBVyxZQUFNO0FBQ2IsZ0NBQVEsV0FBVyxJQUFuQjtBQUNILHFCQUZELEVBRUcsR0FGSDtBQUdILGlCQUpNLENBQVA7QUFLSCxhQVBJO0FBUUwsbUJBQU8saUJBQU07QUFDVCx1QkFBTyxJQUFJLE9BQUosQ0FBWSxVQUFDLE9BQUQsRUFBYTtBQUM1QiwrQkFBVyxZQUFNO0FBQ2IsZ0NBQVEsV0FBVyxVQUFuQjtBQUNILHFCQUZELEVBRUcsR0FGSDtBQUdILGlCQUpNLENBQVA7QUFLSDtBQWRJLFNBTEM7QUFxQlYsZ0JBQVE7QUFDSixrQkFBTSxhQURGO0FBRUosbUJBQU87QUFGSCxTQXJCRTtBQXlCVixrQkFBVTtBQUNOLGtCQUFNLGNBQUMsTUFBRCxFQUFTLElBQVQsRUFBa0I7QUFDcEIsNENBQTBCLE1BQTFCLEdBQW1DLEtBQUssS0FBeEM7QUFDSCxhQUhLO0FBSU4sbUJBQU8sZUFBQyxNQUFELEVBQVMsSUFBVCxFQUFrQjtBQUNyQiwyQ0FBeUIsTUFBekIsR0FBa0MsS0FBSyxLQUF2QztBQUNIO0FBTks7QUF6QkEsS0FBZDs7QUFtQ0EsU0FBSyxPQUFMLEdBQWU7QUFDWCx5QkFBaUIsc0JBRE47QUFFWCxrQkFBVTtBQUNOLG1CQUFPLEdBREQ7QUFFTixrQkFBTTtBQUZBLFNBRkM7QUFNWCxpQkFBUztBQUNMLG1CQUFPLGlCQUFNO0FBQ1QsdUJBQU8sSUFBSSxPQUFKLENBQVksVUFBQyxPQUFELEVBQWE7QUFDNUIsK0JBQVcsWUFBTTtBQUNiLGdDQUFRLFdBQVcsSUFBbkI7QUFDSCxxQkFGRCxFQUVHLEdBRkg7QUFHSCxpQkFKTSxDQUFQO0FBS0gsYUFQSTtBQVFMLGtCQUFNLGdCQUFNO0FBQ1IsdUJBQU8sSUFBSSxPQUFKLENBQVksVUFBQyxPQUFELEVBQWE7QUFDNUIsK0JBQVcsWUFBTTtBQUNiLGdDQUFRLFdBQVcsVUFBbkI7QUFDSCxxQkFGRCxFQUVHLEdBRkg7QUFHSCxpQkFKTSxDQUFQO0FBS0g7QUFkSSxTQU5FO0FBc0JYLGdCQUFRO0FBQ0osbUJBQU8sT0FESDtBQUVKLGtCQUFNO0FBRkYsU0F0Qkc7QUEwQlgsa0JBQVU7QUFDTixtQkFBTyxlQUFDLE1BQUQsRUFBUyxJQUFULEVBQWtCO0FBQ3JCLDZDQUEyQixNQUEzQixHQUFvQyxLQUFLLEtBQXpDO0FBQ0gsYUFISztBQUlOLGtCQUFNLGNBQUMsTUFBRCxFQUFTLElBQVQsRUFBa0I7QUFDcEIsNENBQTBCLE1BQTFCLEdBQW1DLEtBQUssS0FBeEM7QUFDSDtBQU5LO0FBMUJDLEtBQWY7QUFtQ0gsQyIsImZpbGUiOiJRdWlja05vdGVEZW1vLmpzIiwic291cmNlUm9vdCI6Ii9Vc2Vycy9qZ29kaS9ub3ZvLWRldi9saWJzL25vdm8tZWxlbWVudHMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENPUkVfRElSRUNUSVZFUyB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBOT1ZPX1FVSUNLX05PVEVfRUxFTUVOVFMsIFF1aWNrTm90ZVJlc3VsdHMsIE5PVk9fTE9BRElOR19FTEVNRU5UUyB9IGZyb20gJy4vLi4vLi4vLi4vc3JjL25vdm8tZWxlbWVudHMnO1xuXG5pbXBvcnQgeyBDb2RlU25pcHBldCB9IGZyb20gJy4uLy4uL2VsZW1lbnRzL2NvZGVzbmlwcGV0L0NvZGVTbmlwcGV0JztcblxuaW1wb3J0IEJhc2ljUXVpY2tOb3RlRGVtb1RwbCBmcm9tICcuL3RlbXBsYXRlcy9CYXNpY1F1aWNrTm90ZS5odG1sJztcbmltcG9ydCBDdXN0b21RdWlja05vdGVEZW1vVHBsIGZyb20gJy4vdGVtcGxhdGVzL0N1c3RvbVF1aWNrTm90ZS5odG1sJztcbmltcG9ydCBDdXN0b21RdWlja05vdGVSZXN1bHRzRGVtb1RwbCBmcm9tICcuL3RlbXBsYXRlcy9DdXN0b21RdWlja05vdGVSZXN1bHRzLmh0bWwnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2N1c3RvbS1xdWljay1ub3RlLXJlc3VsdHMnLFxuICAgIGRpcmVjdGl2ZXM6IFtOT1ZPX0xPQURJTkdfRUxFTUVOVFNdLFxuICAgIGhvc3Q6IHtcbiAgICAgICAgJ2NsYXNzJzogJ2FjdGl2ZSBxdWljay1ub3RlLXJlc3VsdHMnXG4gICAgfSxcbiAgICB0ZW1wbGF0ZTogYFxuICAgICAgICA8bm92by1sb2FkaW5nIHRoZW1lPVwibGluZVwiICpuZ0lmPVwiaXNMb2FkaW5nICYmICFtYXRjaGVzLmxlbmd0aFwiPjwvbm92by1sb2FkaW5nPlxuICAgICAgICA8dWwgKm5nSWY9XCJtYXRjaGVzLmxlbmd0aCA+IDBcIj5cbiAgICAgICAgICAgIDxsaVxuICAgICAgICAgICAgICAgICpuZ0Zvcj1cImxldCBtYXRjaCBvZiBtYXRjaGVzXCJcbiAgICAgICAgICAgICAgICAoY2xpY2spPVwic2VsZWN0TWF0Y2goJGV2ZW50KVwiXG4gICAgICAgICAgICAgICAgW2NsYXNzLmFjdGl2ZV09XCJtYXRjaD09PWFjdGl2ZU1hdGNoXCJcbiAgICAgICAgICAgICAgICAobW91c2VlbnRlcik9XCJzZWxlY3RBY3RpdmUobWF0Y2gpXCI+XG4gICAgICAgICAgICAgICAgKipDVVNUT00qKiA8YiBbaW5uZXJIdG1sXT1cImhpZ2hsaWdodChtYXRjaC5sYWJlbCwgdGVybSlcIj48L2I+XG4gICAgICAgICAgICA8L2xpPlxuICAgICAgICA8L3VsPlxuICAgICAgICA8cCBjbGFzcz1cInBpY2tlci1lcnJvclwiICpuZ0lmPVwiaGFzRXJyb3JcIj5Pb3BzISBBbiBlcnJvciBvY2N1cmVkLjwvcD5cbiAgICAgICAgPHAgY2xhc3M9XCJwaWNrZXItbnVsbFwiICpuZ0lmPVwiIWlzTG9hZGluZyAmJiAhbWF0Y2hlcy5sZW5ndGggJiYgIWhhc0Vycm9yXCI+Tm8gcmVzdWx0cyB0byBkaXNwbGF5Li4uPC9wPlxuICAgIGBcbn0pXG5leHBvcnQgY2xhc3MgQ3VzdG9tUXVpY2tOb3RlUmVzdWx0cyBleHRlbmRzIFF1aWNrTm90ZVJlc3VsdHMge1xufVxuXG5jb25zdCB0ZW1wbGF0ZSA9IGBcbjxkaXYgY2xhc3M9XCJjb250YWluZXJcIj5cbiAgICA8aDE+UXVpY2sgTm90ZSA8c21hbGw+PGEgdGFyZ2V0PVwiX2JsYW5rXCIgaHJlZj1cImh0dHBzOi8vZ2l0aHViLmNvbS9idWxsaG9ybi9ub3ZvLWVsZW1lbnRzL3RyZWUvbWFzdGVyL3NyYy9lbGVtZW50cy9xdWljay1ub3RlXCI+KHNvdXJjZSk8L2E+PC9zbWFsbD48L2gxPlxuICAgIDxwPlRhZyBBdXRvY29tcGxldGU8L3A+XG5cbiAgICA8YnIvPlxuXG4gICAgPGg1PkJhc2ljIEV4YW1wbGVzPC9oNT5cbiAgICA8ZGl2IGNsYXNzPVwiZXhhbXBsZSBxdWljay1ub3RlLWRlbW9cIj4ke0Jhc2ljUXVpY2tOb3RlRGVtb1RwbH08L2Rpdj5cbiAgICA8Y29kZS1zbmlwcGV0IFtjb2RlXT1cIkJhc2ljUXVpY2tOb3RlRGVtb1RwbFwiPjwvY29kZS1zbmlwcGV0PlxuICAgIFxuICAgIDxoNT5DdXN0b20gVHJpZ2dlcnM8L2g1PlxuICAgIDxkaXYgY2xhc3M9XCJleGFtcGxlIHF1aWNrLW5vdGUtZGVtb1wiPiR7Q3VzdG9tUXVpY2tOb3RlRGVtb1RwbH08L2Rpdj5cbiAgICA8Y29kZS1zbmlwcGV0IFtjb2RlXT1cIkN1c3RvbVF1aWNrTm90ZURlbW9UcGxcIj48L2NvZGUtc25pcHBldD5cbiAgICBcbiAgICA8aDU+Q3VzdG9tIFJlc3VsdHMgVGVtcGxhdGU8L2g1PlxuICAgIDxkaXYgY2xhc3M9XCJleGFtcGxlIHF1aWNrLW5vdGUtZGVtb1wiPiR7Q3VzdG9tUXVpY2tOb3RlUmVzdWx0c0RlbW9UcGx9PC9kaXY+XG4gICAgPGNvZGUtc25pcHBldCBbY29kZV09XCJDdXN0b21RdWlja05vdGVSZXN1bHRzRGVtb1RwbFwiPjwvY29kZS1zbmlwcGV0PlxuPC9kaXY+XG5gO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ3F1aWNrLW5vdGUtZGVtbycsXG4gICAgdGVtcGxhdGU6IHRlbXBsYXRlLFxuICAgIGRpcmVjdGl2ZXM6IFtOT1ZPX1FVSUNLX05PVEVfRUxFTUVOVFMsIENPUkVfRElSRUNUSVZFUywgQ29kZVNuaXBwZXRdXG59KVxuZXhwb3J0IGNsYXNzIFF1aWNrTm90ZURlbW8ge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICB0aGlzLkJhc2ljUXVpY2tOb3RlRGVtb1RwbCA9IEJhc2ljUXVpY2tOb3RlRGVtb1RwbDtcbiAgICAgICAgdGhpcy5DdXN0b21RdWlja05vdGVEZW1vVHBsID0gQ3VzdG9tUXVpY2tOb3RlRGVtb1RwbDtcbiAgICAgICAgdGhpcy5DdXN0b21RdWlja05vdGVSZXN1bHRzRGVtb1RwbCA9IEN1c3RvbVF1aWNrTm90ZVJlc3VsdHNEZW1vVHBsO1xuXG4gICAgICAgIHRoaXMucGxhY2Vob2xkZXIgPSAnRW50ZXIgeW91ciBub3RlIHRleHQgaGVyZS4gUmVmZXJlbmNlIHBlb3BsZSBhbmQgZGlzdHJ1YnV0aW9uIGxpc3RzIHVzaW5nIEAgKGVnLiBASm9obiBTbWl0aCkuIFJlZmVyZW5jZSBvdGhlciByZWNvcmRzIHVzaW5nICMgKGUuZy4gI1Byb2plY3QgTWFuYWdlciknO1xuXG4gICAgICAgIHRoaXMubm90ZSA9ICcnO1xuICAgICAgICB0aGlzLnJlZmVyZW5jZXMgPSB7fTtcblxuICAgICAgICB0aGlzLm5vdGUyID0gJ0kgYW0gYW4gaW5pdGlhbCBub3RlISc7XG4gICAgICAgIHRoaXMucmVmZXJlbmNlczIgPSB7fTtcblxuICAgICAgICB0aGlzLm5vdGUzID0gJyc7XG4gICAgICAgIHRoaXMucmVmZXJlbmNlczMgPSB7fTtcblxuICAgICAgICBsZXQgY3VzdG9tRGF0YSA9IHtcbiAgICAgICAgICAgIHRhZ3M6IFt7IGlkOiAxLCBuYW1lOiAnT0ggWUEhJywgdGVzdDogJ1RXTycgfSwgeyBpZDogMiwgbmFtZTogJ1RBR0dJTkchJywgdGVzdDogJ09ORScgfV0sXG4gICAgICAgICAgICByZWZlcmVuY2VzOiBbeyBpZDogMSwgdGl0bGU6ICdBd2Vzb21lIFJlZmVyZW5jZScgfSwgeyBpZDogMiwgdGl0bGU6ICdBbmd1bGFyMicgfV1cbiAgICAgICAgfTtcblxuICAgICAgICB0aGlzLmNvbmZpZyA9IHtcbiAgICAgICAgICAgIHRyaWdnZXJzOiB7XG4gICAgICAgICAgICAgICAgdGFnczogJ0AnLFxuICAgICAgICAgICAgICAgIHJlZmVyZW5jZXM6ICcjJyxcbiAgICAgICAgICAgICAgICBib29zOiAnXidcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBvcHRpb25zOiB7XG4gICAgICAgICAgICAgICAgdGFnczogWydGaXJzdCcsICdTZWNvbmQnXSxcbiAgICAgICAgICAgICAgICByZWZlcmVuY2VzOiBbJ1RoaXJkJywgJ0ZvcnRoJ10sXG4gICAgICAgICAgICAgICAgYm9vczogWydUZXN0J11cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICByZW5kZXJlcjoge1xuICAgICAgICAgICAgICAgIHRhZ3M6IChzeW1ib2wsIGl0ZW0pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGA8YSBjbGFzcz1cInRhZ1wiPiR7c3ltYm9sfSR7aXRlbS5sYWJlbH08L2E+YDtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHJlZmVyZW5jZXM6IChzeW1ib2wsIGl0ZW0pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGA8YSBjbGFzcz1cInRhZ1wiPiR7c3ltYm9sfSR7aXRlbS5sYWJlbH08L2E+YDtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGJvb3M6IChzeW1ib2wsIGl0ZW0pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGA8c3Ryb25nPiR7c3ltYm9sfSR7aXRlbS5sYWJlbH08L3N0cm9uZz5gO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICB0aGlzLmN1c3RvbSA9IHtcbiAgICAgICAgICAgIHRyaWdnZXJzOiB7XG4gICAgICAgICAgICAgICAgd2hvczogJ0AnLFxuICAgICAgICAgICAgICAgIHdoYXRzOiAnIydcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBvcHRpb25zOiB7XG4gICAgICAgICAgICAgICAgd2hvczogKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUoY3VzdG9tRGF0YS50YWdzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sIDMwMCk7XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgd2hhdHM6ICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKGN1c3RvbURhdGEucmVmZXJlbmNlcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9LCAzMDApO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZm9ybWF0OiB7XG4gICAgICAgICAgICAgICAgd2hvczogJyRuYW1lICR0ZXN0JyxcbiAgICAgICAgICAgICAgICB3aGF0czogJyR0aXRsZSdcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICByZW5kZXJlcjoge1xuICAgICAgICAgICAgICAgIHdob3M6IChzeW1ib2wsIGl0ZW0pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGA8YSBjbGFzcz1cIldIT1NcIj4ke3N5bWJvbH0ke2l0ZW0ubGFiZWx9PC9hPmA7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB3aGF0czogKHN5bWJvbCwgaXRlbSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gYDxhIGNsYXNzPVwidGFnXCI+JHtzeW1ib2x9JHtpdGVtLmxhYmVsfTwvYT5gO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICB0aGlzLmN1c3RvbTIgPSB7XG4gICAgICAgICAgICByZXN1bHRzVGVtcGxhdGU6IEN1c3RvbVF1aWNrTm90ZVJlc3VsdHMsXG4gICAgICAgICAgICB0cmlnZ2Vyczoge1xuICAgICAgICAgICAgICAgIG5hbWVzOiAnQCcsXG4gICAgICAgICAgICAgICAgdGFnczogJyMnXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgb3B0aW9uczoge1xuICAgICAgICAgICAgICAgIG5hbWVzOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShjdXN0b21EYXRhLnRhZ3MpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSwgMzAwKTtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB0YWdzOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShjdXN0b21EYXRhLnJlZmVyZW5jZXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSwgMzAwKTtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGZvcm1hdDoge1xuICAgICAgICAgICAgICAgIG5hbWVzOiAnJG5hbWUnLFxuICAgICAgICAgICAgICAgIHRhZ3M6ICckdGl0bGUnXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmVuZGVyZXI6IHtcbiAgICAgICAgICAgICAgICBuYW1lczogKHN5bWJvbCwgaXRlbSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gYDxhIGNsYXNzPVwibmFtZXNcIj4ke3N5bWJvbH0ke2l0ZW0ubGFiZWx9PC9hPmA7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB0YWdzOiAoc3ltYm9sLCBpdGVtKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBgPGEgY2xhc3M9XCJ0YWdzXCI+JHtzeW1ib2x9JHtpdGVtLmxhYmVsfTwvYT5gO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICB9XG59XG4iXX0=

/***/ },

/***/ 879:
/***/ function(module, exports) {

	module.exports = "<novo-quick-note [(ngModel)]=\"note\" [references]=\"references\" [placeholder]=\"placeholder\" [config]=\"config\"></novo-quick-note>\n<div class=\"data\">\n    <p>Note: {{note}}</p>\n    <p>References: {{references | json}}</p>\n</div>\n"

/***/ },

/***/ 880:
/***/ function(module, exports) {

	module.exports = "<novo-quick-note [(ngModel)]=\"note2\" [references]=\"references2\" [placeholder]=\"placeholder\" [config]=\"custom\"></novo-quick-note>\n<div class=\"data\">\n    <p>Note: {{note2}}</p>\n    <p>References: {{references2 | json}}</p>\n</div>\n"

/***/ },

/***/ 881:
/***/ function(module, exports) {

	module.exports = "<novo-quick-note [(ngModel)]=\"note3\" [references]=\"references3\" [placeholder]=\"placeholder\" [config]=\"custom2\"></novo-quick-note>\n<div class=\"data\">\n    <p>Note: {{note3}}</p>\n    <p>References: {{references3 | json}}</p>\n</div>\n"

/***/ }

});
//# sourceMappingURL=9.b3a4dfe6e7ad8bb462c0.bundle.map